# Backup CUI Protection Procedure

**Template ID:** MP-PROC-004  
**Artifact Type:** Procedure  
**Mapped CMMC Level 2 Controls:** 3.8.9  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines safeguards for backup media, backup repositories, and backup storage locations containing CUI.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SYSTEM_OWNER_TITLE}} approves the business use of media containing CUI.
- {{IT_ADMIN_TITLE}} enforces removable media, encryption, backup, and sanitization controls.
- {{SECURITY_OFFICER_TITLE}} reviews media handling records and CUI transport exceptions.
- Users must mark, protect, transport, store, and dispose of media containing CUI only as authorized.

## 5. Procedure
1. Identify backup jobs, repositories, media, and storage locations that contain or may contain CUI.
2. Protect backup CUI using encryption, access control, physical control, and monitoring appropriate to the storage location.
3. Limit backup administration and restore access to authorized personnel.
4. Review backup storage protections at {{BACKUP_REVIEW_FREQUENCY}} and after material system changes.
5. Document backup locations, retention, encryption status, access permissions, and restore test evidence where applicable.

## 6. Required Table / Record Template
### Backup CUI Protection Register
|Backup Job/Repository|CUI Systems Covered|Storage Location|Encryption|Access Controls|Retention|Owner|Last Review|Restore Test Date|Evidence Link|
|---|---|---|---|---|---|---|---|---|---|
|||||||||||

## 7. Evidence and Retention
- Backup configuration evidence
- Access review evidence
- Encryption evidence
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
