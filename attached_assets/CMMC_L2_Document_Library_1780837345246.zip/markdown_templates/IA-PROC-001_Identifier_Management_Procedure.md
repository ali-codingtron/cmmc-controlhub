# Identifier Management Procedure

**Template ID:** IA-PROC-001  
**Artifact Type:** Procedure  
**Mapped CMMC Level 2 Controls:** 3.5.1, 3.5.2  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines creation, assignment, review, disabling, and uniqueness requirements for user, process, service, and device identifiers.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{IT_ADMIN_TITLE}} issues, disables, and manages identifiers and authenticators.
- {{SECURITY_OFFICER_TITLE}} establishes authentication standards and reviews exceptions.
- {{SYSTEM_OWNER_TITLE}} approves access requiring elevated authentication or shared service usage.
- Users must protect passwords, tokens, certificates, recovery codes, and other authenticators.

## 5. Procedure
1. Create identifiers only after approved access request and identity validation.
2. Assign identifiers uniquely to one individual, process, service, or device owner; shared identifiers require documented exception and compensating controls.
3. Disable identifiers immediately upon termination, transfer, compromise, contract end, or loss of business need.
4. Review active identifiers at {{IDENTIFIER_REVIEW_FREQUENCY}} to detect orphaned, inactive, duplicate, or unauthorized accounts.
5. Document ownership and purpose for service, device, emergency, and administrative identifiers.

## 6. Required Table / Record Template
### Identifier Inventory and Review Log
|Identifier|Type|Assigned User/Owner|System|Purpose|Privileged?|Created Date|Last Used|Review Result|Action Required|Closed Date|
|---|---|---|---|---|---|---|---|---|---|---|
||||||||||||

## 7. Evidence and Retention
- Identifier inventory
- Account review evidence
- Disabled account list
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
