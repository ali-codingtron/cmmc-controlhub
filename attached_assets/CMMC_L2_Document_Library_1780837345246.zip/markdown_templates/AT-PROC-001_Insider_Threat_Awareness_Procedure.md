# Insider Threat Awareness Procedure

**Template ID:** AT-PROC-001  
**Artifact Type:** Procedure  
**Mapped CMMC Level 2 Controls:** 3.2.3  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines how {{ORGANIZATION_NAME}} provides awareness on identifying and reporting potential indicators of insider threat.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SECURITY_OFFICER_TITLE}} owns training content and completion monitoring.
- {{SYSTEM_OWNER_TITLE}} identifies role-based training needs for personnel with CUI responsibilities.
- Managers ensure personnel complete required training before access is granted and at required intervals.
- Users complete training and acknowledge applicable policies, standards, and procedures.

## 5. Procedure
1. Include insider threat indicators in onboarding and annual security training.
2. Train personnel to report unusual access requests, attempted policy bypass, unexplained data movement, disgruntled behavior, credential sharing, and unauthorized removable media use.
3. Provide reporting channels such as {{SECURITY_CONTACT_EMAIL}}, help desk, supervisor, or incident reporting portal.
4. Escalate reported indicators to the incident response process and preserve confidentiality on a need-to-know basis.
5. Track completion and update training based on lessons learned.

## 7. Evidence and Retention
- Insider threat training materials
- Training completion evidence
- Related incident or concern reports
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
