# Identification and Authentication Policy

**Template ID:** IA-POL-001  
**Artifact Type:** Policy  
**Mapped CMMC Level 2 Controls:** 3.5.1, 3.5.2, 3.5.3, 3.5.4, 3.5.5, 3.5.6, 3.5.7, 3.5.8, 3.5.9, 3.5.10, 3.5.11  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Establishes requirements for unique identification, authentication, authenticator lifecycle management, MFA, password controls, and protection of authenticators.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{IT_ADMIN_TITLE}} issues, disables, and manages identifiers and authenticators.
- {{SECURITY_OFFICER_TITLE}} establishes authentication standards and reviews exceptions.
- {{SYSTEM_OWNER_TITLE}} approves access requiring elevated authentication or shared service usage.
- Users must protect passwords, tokens, certificates, recovery codes, and other authenticators.

## 4. Requirements
- Users, processes, and devices must be uniquely identified before access to CUI systems is granted.
- Authentication must be enforced for users, processes, and devices based on role, access method, and system capability.
- MFA must be used for privileged accounts and remote access, and for other access where required by {{ORGANIZATION_NAME}} policy or contract.
- Authenticators must be protected against disclosure, reuse, unauthorized modification, and compromise.
- Passwords and temporary authenticators must meet documented complexity, reuse, expiration, reset, and delivery requirements.
- Default passwords and authenticators must be changed before system use.

## 7. Evidence and Retention
- Identifier inventory
- Authenticator inventory
- MFA configuration evidence
- Password policy evidence
- Authenticator reset logs
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
