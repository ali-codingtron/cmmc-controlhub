# Logon, Session Lock, Session Termination, and System Use Notification Standard

**Template ID:** AC-STD-002  
**Artifact Type:** Standard  
**Mapped CMMC Level 2 Controls:** 3.1.8, 3.1.9, 3.1.10, 3.1.11  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines baseline settings for unsuccessful logon attempts, warning banners, session lock, pattern hiding, and session termination.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SYSTEM_OWNER_TITLE}} approves access based on business need and CUI handling requirements.
- {{IT_ADMIN_TITLE}} implements, changes, and disables logical access in approved systems.
- {{SECURITY_OFFICER_TITLE}} reviews privileged access, remote access, exceptions, and audit evidence.
- Users must protect authenticators, use only approved access methods, and immediately report suspected unauthorized access.

## 4. Requirements
- Unsuccessful logon attempts must be limited to {{FAILED_LOGON_THRESHOLD}} attempts within {{FAILED_LOGON_WINDOW}} before lockout or delay enforcement.
- Interactive systems must display an approved privacy and security notice before access is granted.
- Sessions must lock after {{SESSION_LOCK_MINUTES}} minutes of inactivity and hide previously visible information using a pattern-hiding display.
- Sessions must terminate automatically after {{SESSION_TERMINATION_CONDITION}} or when defined risk conditions are met.
- Changes to logon, lockout, or session settings must follow configuration/change management procedures.

## 6. Required Table / Record Template
### System Use Notification Banner Approval
|System|Banner Version|Legal/Security Reviewer|Approval Date|Implemented By|Implementation Date|Review Date|Notes|
|---|---|---|---|---|---|---|---|
|||||||||

## 7. Evidence and Retention
- Configuration evidence
- Banner approvals
- Session policy screenshots
- Audit logs for lockout events
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
