# Account Management and Access Authorization Procedure

**Template ID:** AC-PROC-001  
**Artifact Type:** Procedure  
**Mapped CMMC Level 2 Controls:** 3.1.1, 3.1.2, 3.1.5, 3.1.6, 3.1.7, 3.1.20, 3.1.21, 3.1.22  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines the workflow for requesting, approving, provisioning, reviewing, modifying, and disabling access to CUI systems.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SYSTEM_OWNER_TITLE}} approves access based on business need and CUI handling requirements.
- {{IT_ADMIN_TITLE}} implements, changes, and disables logical access in approved systems.
- {{SECURITY_OFFICER_TITLE}} reviews privileged access, remote access, exceptions, and audit evidence.
- Users must protect authenticators, use only approved access methods, and immediately report suspected unauthorized access.

## 5. Procedure
1. Requester submits an access request identifying user, role, system, business justification, CUI need-to-know, and requested duration.
2. {{SYSTEM_OWNER_TITLE}} validates need-to-know, role suitability, separation of duties, and whether privileged access is required.
3. {{IT_ADMIN_TITLE}} provisions access only after documented approval and records the user, role, device, group membership, and effective date.
4. Privileged and administrative access must be assigned to dedicated accounts unless technically infeasible and must not be used for routine nonsecurity functions.
5. Access must be modified or disabled when personnel transfer, separate, no longer require access, violate policy, or when risk conditions change.
6. {{SECURITY_OFFICER_TITLE}} reviews access at {{ACCESS_REVIEW_FREQUENCY}} and documents findings, remediation, and approvals.

## 6. Required Table / Record Template
### Access Authorization Record
|Request ID|User/Process/Device|System/Application|Role or Group|Access Type|Business Justification|CUI Need-to-Know|Approver|Provisioned By|Effective Date|Expiration/Review Date|Status|Notes|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
||||||||||||||

## 7. Evidence and Retention
- Access requests and approvals
- Account disablement records
- Access review results
- Group and role membership records
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
