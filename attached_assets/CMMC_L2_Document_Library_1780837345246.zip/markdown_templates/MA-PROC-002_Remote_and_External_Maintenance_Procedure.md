# Remote and External Maintenance Procedure

**Template ID:** MA-PROC-002  
**Artifact Type:** Procedure  
**Mapped CMMC Level 2 Controls:** 3.7.4, 3.7.5, 3.7.6  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines safeguards for remote maintenance, maintenance sessions, nonlocal maintenance personnel, and authentication requirements.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{IT_ADMIN_TITLE}} plans and performs maintenance using approved tools and methods.
- {{SYSTEM_OWNER_TITLE}} approves maintenance that affects CUI systems or service availability.
- {{SECURITY_OFFICER_TITLE}} reviews remote maintenance, sanitization, and access evidence.
- External maintenance personnel must be authorized, supervised, logged, and limited to approved activities.

## 5. Procedure
1. Remote maintenance must be pre-approved with identified technician, company, purpose, system, access method, time window, and monitoring owner.
2. Remote sessions must use approved authentication and encrypted channels and must be terminated after work is complete.
3. Remote maintenance activity must be monitored by authorized personnel or recorded using approved tools where available.
4. External maintenance personnel without required authorization must be escorted, supervised, or have access technically restricted.
5. Temporary accounts or access paths must be disabled immediately after maintenance completion.

## 6. Required Table / Record Template
### Remote Maintenance Authorization and Session Log
|Date|Vendor/Technician|System|Purpose|Access Method|Approved Window|Monitor|Start Time|End Time|Actions Performed|Account Disabled?|Evidence Link|
|---|---|---|---|---|---|---|---|---|---|---|---|
|||||||||||||

## 7. Evidence and Retention
- Remote maintenance approvals
- Session logs
- Temporary account disablement evidence
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
