# CUI Flow Control and Data Transfer Procedure

**Template ID:** AC-PROC-005  
**Artifact Type:** Procedure  
**Mapped CMMC Level 2 Controls:** 3.1.3  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines approved CUI data flows, transfer channels, boundary enforcement points, and authorization requirements for CUI movement.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SYSTEM_OWNER_TITLE}} approves access based on business need and CUI handling requirements.
- {{IT_ADMIN_TITLE}} implements, changes, and disables logical access in approved systems.
- {{SECURITY_OFFICER_TITLE}} reviews privileged access, remote access, exceptions, and audit evidence.
- Users must protect authenticators, use only approved access methods, and immediately report suspected unauthorized access.

## 5. Procedure
1. Identify all authorized CUI sources, destinations, repositories, users, systems, and transfer paths in the system boundary.
2. Define approved authorizations for data transfers, including internal transfer, external transfer, subcontractor transfer, encrypted email, portal exchange, removable media, and API/system integration.
3. Configure boundary controls, DLP rules, firewall rules, labels, permissions, or workflow approvals to enforce approved CUI flows.
4. Block or route unapproved CUI transfers for security review before release.
5. Review CUI flow diagrams, transfer records, and exceptions at {{CUI_FLOW_REVIEW_FREQUENCY}}.

## 6. Required Table / Record Template
### CUI Data Flow Authorization Table
|Source|Destination|Data Type/CUI Category|Transfer Method|Encryption/Protection|Approver|Business Purpose|Allowed/Denied|Review Date|Notes|
|---|---|---|---|---|---|---|---|---|---|
|||||||||||

## 7. Evidence and Retention
- Data flow diagram
- Transfer authorization table
- DLP/labeling rules
- Boundary control evidence
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
