# Personnel Transfer and Termination Procedure and Checklist

**Template ID:** PS-PROC-002  
**Artifact Type:** Procedure/Checklist  
**Mapped CMMC Level 2 Controls:** 3.9.2  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines actions required to protect CUI systems during and after personnel transfer, termination, or role change.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{HR_OWNER_TITLE}} performs screening, termination, and transfer notifications.
- {{SYSTEM_OWNER_TITLE}} approves system access after personnel screening and need-to-know validation.
- {{IT_ADMIN_TITLE}} executes access revocation, account disablement, and credential recovery.
- {{SECURITY_OFFICER_TITLE}} validates completion of personnel security evidence.

## 5. Procedure
1. {{HR_OWNER_TITLE}} notifies {{IT_ADMIN_TITLE}}, {{SYSTEM_OWNER_TITLE}}, and {{SECURITY_OFFICER_TITLE}} of transfer, termination, contract end, or role change within {{HR_NOTIFICATION_TIMEFRAME}}.
2. {{IT_ADMIN_TITLE}} disables or modifies system access, revokes sessions, recovers devices/media, resets shared secrets if needed, and documents completion.
3. {{FACILITY_OWNER_TITLE}} recovers badges, keys, physical access devices, and facility credentials.
4. {{SECURITY_OFFICER_TITLE}} reviews privileged access, external system access, and any unresolved CUI transfer or return obligations.
5. Complete checklist and retain evidence of all actions.

## 6. Required Table / Record Template
### Transfer/Termination Access Revocation Checklist
|Person|Action Type|Effective Date|Logical Access Disabled/Modified|MFA/Authenticator Revoked|Device/Media Returned|Physical Access Revoked|External Access Revoked|Performed By|Completion Date|Evidence Link|Notes|
|---|---|---|---|---|---|---|---|---|---|---|---|
|||||||||||||

## 7. Evidence and Retention
- Termination checklist
- Transfer access review
- Credential recovery records
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
