# Physical Protection Policy

**Template ID:** PE-POL-001  
**Artifact Type:** Policy  
**Mapped CMMC Level 2 Controls:** 3.10.1, 3.10.2, 3.10.3, 3.10.4, 3.10.5, 3.10.6  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Establishes requirements for physical access authorization, monitoring, visitor escort, physical access logs, access device management, and alternate work site safeguards.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{FACILITY_OWNER_TITLE}} manages physical access, visitor controls, and access devices.
- {{SYSTEM_OWNER_TITLE}} defines controlled areas where CUI systems or media are located.
- {{SECURITY_OFFICER_TITLE}} reviews physical access logs, device inventory, and exceptions.
- Employees and visitors must comply with escorting, badging, clean desk, and controlled area requirements.

## 4. Requirements
- Physical access to CUI systems, equipment, operating environments, media, and support infrastructure must be limited to authorized individuals.
- Controlled areas must be identified and protected using appropriate physical safeguards such as locked rooms, badges, keys, monitoring, visitor escort, and access logs.
- Visitors must be escorted and monitored in controlled areas unless specifically authorized by policy.
- Physical access logs and access device records must be maintained and reviewed at {{PHYSICAL_ACCESS_REVIEW_FREQUENCY}}.
- Alternate work sites must protect CUI from unauthorized access, observation, disclosure, loss, and theft.

## 7. Evidence and Retention
- Physical access authorizations
- Visitor logs
- Access device inventory
- Physical access reviews
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
