# Facility Physical Access and Monitoring Procedure

**Template ID:** PE-PROC-001  
**Artifact Type:** Procedure  
**Mapped CMMC Level 2 Controls:** 3.10.1, 3.10.2, 3.10.4  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines physical access control and monitoring procedures for facilities and areas supporting CUI systems.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{FACILITY_OWNER_TITLE}} manages physical access, visitor controls, and access devices.
- {{SYSTEM_OWNER_TITLE}} defines controlled areas where CUI systems or media are located.
- {{SECURITY_OFFICER_TITLE}} reviews physical access logs, device inventory, and exceptions.
- Employees and visitors must comply with escorting, badging, clean desk, and controlled area requirements.

## 5. Procedure
1. Identify controlled areas containing CUI systems, media, network equipment, backup repositories, or support infrastructure.
2. Authorize physical access based on role, business need, screening status, and approval by the area owner.
3. Protect controlled areas using approved physical controls such as locks, badges, keys, alarms, cameras, visitor controls, or other safeguards.
4. Maintain physical access records sufficient to identify who accessed controlled areas and when.
5. Review physical access authorizations and logs at {{PHYSICAL_ACCESS_REVIEW_FREQUENCY}} and remediate unauthorized or unnecessary access.

## 6. Required Table / Record Template
### Physical Access Review Log
|Review Date|Area/System|Access List Reviewed|Unauthorized/Unneeded Access Found|Action Taken|Reviewer|Completion Date|Evidence Link|
|---|---|---|---|---|---|---|---|
|||||||||

## 7. Evidence and Retention
- Access list
- Access log
- Review evidence
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
