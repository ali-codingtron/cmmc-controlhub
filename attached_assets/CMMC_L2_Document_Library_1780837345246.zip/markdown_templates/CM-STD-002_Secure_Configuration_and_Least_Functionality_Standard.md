# Secure Configuration and Least Functionality Standard

**Template ID:** CM-STD-002  
**Artifact Type:** Standard  
**Mapped CMMC Level 2 Controls:** 3.4.2, 3.4.5, 3.4.6  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines secure configuration expectations and least functionality rules for CUI systems.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SYSTEM_OWNER_TITLE}} approves baseline configurations and production changes.
- {{IT_ADMIN_TITLE}} maintains configuration baselines, software inventories, and secure settings.
- {{SECURITY_OFFICER_TITLE}} reviews security impact, change evidence, and configuration drift.
- Users may not install software or alter configurations unless explicitly authorized.

## 4. Requirements
- Systems must be configured according to approved secure baseline guidance such as vendor hardening guidance, CIS benchmarks, DISA STIGs where applicable, or organization-approved equivalent settings.
- Unnecessary services, ports, protocols, default accounts, sample applications, and unsupported software must be disabled or removed.
- Allowed functionality must be documented; prohibited or restricted functionality must be blocked by configuration or technical controls.
- Configuration drift must be reviewed at {{CONFIGURATION_REVIEW_FREQUENCY}} and remediated or documented as an approved exception.

## 6. Required Table / Record Template
### Secure Configuration Checklist
|System|Requirement/Setting|Approved Value|Current Value|Compliant?|Exception ID|Remediation Owner|Due Date|Validation Evidence|
|---|---|---|---|---|---|---|---|---|
||||||||||

## 7. Evidence and Retention
- Secure configuration checklist
- Configuration scan results
- Deviation and exception records
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
