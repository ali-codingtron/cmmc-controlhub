# Access Control Policy

**Template ID:** AC-POL-001  
**Artifact Type:** Policy  
**Mapped CMMC Level 2 Controls:** 3.1.1, 3.1.2, 3.1.3, 3.1.4, 3.1.5, 3.1.6, 3.1.7, 3.1.8, 3.1.9, 3.1.10, 3.1.11, 3.1.12, 3.1.13, 3.1.14, 3.1.15, 3.1.16, 3.1.17, 3.1.18, 3.1.19, 3.1.20, 3.1.21, 3.1.22  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Establishes mandatory access control requirements for authorizing, limiting, monitoring, and reviewing access to CUI systems and data.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SYSTEM_OWNER_TITLE}} approves access based on business need and CUI handling requirements.
- {{IT_ADMIN_TITLE}} implements, changes, and disables logical access in approved systems.
- {{SECURITY_OFFICER_TITLE}} reviews privileged access, remote access, exceptions, and audit evidence.
- Users must protect authenticators, use only approved access methods, and immediately report suspected unauthorized access.

## 4. Requirements
- Access to {{SYSTEM_NAME}} must be limited to authorized users, authorized processes acting on behalf of users, and authorized devices or systems.
- Access rights must be based on documented business need, least privilege, separation of duties, and CUI handling responsibilities.
- Privileged access must be explicitly approved, uniquely assigned where technically feasible, and periodically reviewed.
- Remote, wireless, mobile, external system, and public content access must be controlled using approved procedures and documented authorizations.
- CUI must not be posted to publicly accessible systems unless explicitly approved by {{SECURITY_OFFICER_TITLE}} and verified as releasable.
- Access exceptions must be documented, risk-reviewed, time-bound, and approved by {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 7. Evidence and Retention
- Access authorization records
- Active account list
- Privileged access review evidence
- Remote/wireless/mobile authorizations
- Public content review records
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
