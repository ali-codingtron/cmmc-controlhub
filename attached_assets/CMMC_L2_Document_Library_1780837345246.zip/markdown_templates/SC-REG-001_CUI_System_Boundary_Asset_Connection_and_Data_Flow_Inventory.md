# CUI System Boundary, Asset, Connection, and Data Flow Inventory

**Template ID:** SC-REG-001  
**Artifact Type:** Inventory  
**Mapped CMMC Level 2 Controls:** 3.1.3, 3.12.4, 3.13.1, 3.13.2, 3.13.5, 3.13.6  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Provides a standard inventory for system components, boundaries, interconnections, CUI data flows, and protection roles.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{IT_ADMIN_TITLE}} manages network, encryption, boundary, session, and communications controls.
- {{SYSTEM_OWNER_TITLE}} approves architecture, external connections, and risk-based exceptions.
- {{SECURITY_OFFICER_TITLE}} reviews firewall rules, cryptographic controls, and network evidence.
- Users may only transmit, store, or access CUI through approved channels and systems.

## 6. Required Table / Record Template
### CUI Boundary and Asset Inventory
|Asset/Connection/Data Flow|Type|Owner|Location|In Scope?|CUI Stored/Processed/Transmitted|Protection Role|Source|Destination|Security Control/Boundary|Evidence Link|Notes|
|---|---|---|---|---|---|---|---|---|---|---|---|
|||||||||||||

## 7. Evidence and Retention
- Boundary inventory
- Data flow inventory
- Network connection inventory
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
