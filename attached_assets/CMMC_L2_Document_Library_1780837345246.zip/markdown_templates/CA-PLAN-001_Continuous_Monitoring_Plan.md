# Continuous Monitoring Plan

**Template ID:** CA-PLAN-001  
**Artifact Type:** Plan  
**Mapped CMMC Level 2 Controls:** 3.12.3  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines ongoing monitoring activities used to ensure security controls remain effective over time.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SECURITY_OFFICER_TITLE}} owns control assessment, POA&M management, continuous monitoring, and SSP updates.
- {{SYSTEM_OWNER_TITLE}} approves the system boundary, control implementation status, and residual risk.
- {{IT_ADMIN_TITLE}} provides technical evidence and remediation updates.
- Control owners maintain evidence and notify the security owner of material changes.

## 4. Requirements
- Monitoring activities must include access reviews, vulnerability scanning, log reviews, backup protection reviews, firewall rule reviews, training completion review, privileged access review, media review, physical access review, and POA&M review.
- Each monitoring task must identify owner, frequency, evidence, success criteria, escalation criteria, and evidence retention location.
- Monitoring results must feed risk assessment, control assessment, POA&M, and management reporting.

## 6. Required Table / Record Template
### Continuous Monitoring Task Schedule
|Task|Mapped Controls|Owner|Frequency|Evidence Produced|Success Criteria|Escalation Criteria|Last Completed|Next Due|Status|
|---|---|---|---|---|---|---|---|---|---|
|||||||||||

## 7. Evidence and Retention
- Monitoring schedule
- Completed monitoring records
- Escalation evidence
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
