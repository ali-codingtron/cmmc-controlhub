# Controlled Maintenance Procedure

**Template ID:** MA-PROC-001  
**Artifact Type:** Procedure  
**Mapped CMMC Level 2 Controls:** 3.7.1, 3.7.2, 3.7.3  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines how maintenance is planned, approved, performed, logged, validated, and closed for CUI systems.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{IT_ADMIN_TITLE}} plans and performs maintenance using approved tools and methods.
- {{SYSTEM_OWNER_TITLE}} approves maintenance that affects CUI systems or service availability.
- {{SECURITY_OFFICER_TITLE}} reviews remote maintenance, sanitization, and access evidence.
- External maintenance personnel must be authorized, supervised, logged, and limited to approved activities.

## 5. Procedure
1. Create a maintenance record identifying system, purpose, requester, technician, schedule, expected impact, and CUI considerations.
2. Approve maintenance before work begins unless emergency maintenance is necessary to protect the system or data.
3. Control and monitor maintenance activity; limit access to authorized systems, tools, and time periods.
4. Inspect maintenance tools and media for malicious code or unauthorized content before use when technically feasible.
5. Sanitize equipment or remove CUI before off-site maintenance or disposal when applicable.
6. Validate system operation and security controls after maintenance and document completion.

## 6. Required Table / Record Template
### Maintenance Record
|Maintenance ID|System/Asset|Type|Reason|Technician|Internal/External|Approved By|Start/End Time|CUI Present?|Tools Used|Validation Performed|Status|Evidence Link|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
||||||||||||||

## 7. Evidence and Retention
- Maintenance record
- Validation evidence
- Tool inspection record
- Sanitization evidence
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
