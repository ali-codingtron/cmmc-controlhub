# Training Completion Register

**Template ID:** AT-REG-001  
**Artifact Type:** Register/Table  
**Mapped CMMC Level 2 Controls:** 3.2.1, 3.2.2, 3.2.3  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Provides a standard register for tracking required training completion and overdue items.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SECURITY_OFFICER_TITLE}} owns training content and completion monitoring.
- {{SYSTEM_OWNER_TITLE}} identifies role-based training needs for personnel with CUI responsibilities.
- Managers ensure personnel complete required training before access is granted and at required intervals.
- Users complete training and acknowledge applicable policies, standards, and procedures.

## 6. Required Table / Record Template
### Training Completion Register
|Employee/Contractor|Role|Required Modules|Assigned Date|Due Date|Completion Date|Score/Acknowledgement|Evidence Link|Overdue?|Manager Follow-up|Notes|
|---|---|---|---|---|---|---|---|---|---|---|
||||||||||||

## 7. Evidence and Retention
- Training completion register
- Acknowledgements
- Overdue remediation records
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
