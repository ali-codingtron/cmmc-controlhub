# Configuration Management Policy

**Template ID:** CM-POL-001  
**Artifact Type:** Policy  
**Mapped CMMC Level 2 Controls:** 3.4.1, 3.4.2, 3.4.3, 3.4.4, 3.4.5, 3.4.6, 3.4.7, 3.4.8, 3.4.9  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Establishes requirements for secure baseline configuration, change control, security impact analysis, least functionality, and software control.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SYSTEM_OWNER_TITLE}} approves baseline configurations and production changes.
- {{IT_ADMIN_TITLE}} maintains configuration baselines, software inventories, and secure settings.
- {{SECURITY_OFFICER_TITLE}} reviews security impact, change evidence, and configuration drift.
- Users may not install software or alter configurations unless explicitly authorized.

## 4. Requirements
- Baseline configurations must be established, documented, approved, maintained, and reviewed for all CUI systems and components.
- Changes to CUI systems must be authorized, documented, tested when appropriate, assessed for security impact, and tracked through closure.
- Systems must be configured to provide only essential capabilities and restrict unnecessary services, ports, protocols, and software.
- Software installation must be controlled using allow lists, deny lists, application control, administrative approval, or equivalent mechanisms.
- Configuration evidence must be retained to demonstrate current state and change history.

## 7. Evidence and Retention
- Baseline configuration records
- Change approvals
- Security impact analysis
- Software inventory
- Configuration checklists
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
