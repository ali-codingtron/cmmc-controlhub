# Security Awareness and Training Policy

**Template ID:** AT-POL-001  
**Artifact Type:** Policy  
**Mapped CMMC Level 2 Controls:** 3.2.1, 3.2.2, 3.2.3  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Establishes requirements for security awareness, role-based training, CUI handling training, and insider threat awareness.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SECURITY_OFFICER_TITLE}} owns training content and completion monitoring.
- {{SYSTEM_OWNER_TITLE}} identifies role-based training needs for personnel with CUI responsibilities.
- Managers ensure personnel complete required training before access is granted and at required intervals.
- Users complete training and acknowledge applicable policies, standards, and procedures.

## 4. Requirements
- Personnel must receive security awareness training before accessing CUI systems and at least annually thereafter.
- Managers, system administrators, users, and personnel with security responsibilities must be trained on applicable policies, procedures, standards, and CUI risks.
- Role-based training must be provided for users with elevated privileges, security responsibilities, incident response responsibilities, or specialized CUI handling duties.
- Training must include recognizing and reporting potential insider threat indicators.
- Training completion must be documented and retained as evidence.

## 7. Evidence and Retention
- Training curriculum
- Training completion records
- Role-based training assignments
- Insider threat awareness records
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
