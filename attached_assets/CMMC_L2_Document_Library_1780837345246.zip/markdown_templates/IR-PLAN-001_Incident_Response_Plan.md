# Incident Response Plan

**Template ID:** IR-PLAN-001  
**Artifact Type:** Plan  
**Mapped CMMC Level 2 Controls:** 3.6.1, 3.6.2, 3.6.3  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Provides a ready-to-use incident response plan for CUI environments.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SECURITY_OFFICER_TITLE}} leads incident handling, evidence preservation, and reporting coordination.
- {{SYSTEM_OWNER_TITLE}} supports business impact decisions and remediation prioritization.
- {{IT_ADMIN_TITLE}} performs containment, eradication, recovery, and technical evidence collection.
- All personnel must promptly report suspected incidents, CUI exposure, account compromise, malware, or policy violations.

## 4. Requirements
- The incident response lifecycle includes preparation, detection, analysis, containment, eradication, recovery, post-incident review, and reporting.
- Severity must be based on impact to CUI confidentiality, integrity, system availability, mission, contractual obligations, legal/regulatory requirements, and likelihood of continued threat activity.
- The response team must maintain contact information for internal stakeholders, outside counsel, cyber insurance, MSP/MSSP, federal reporting contacts, and affected system owners.
- Evidence must be preserved using documented chain-of-custody practices when an incident may require legal, contractual, or third-party review.

## 6. Required Table / Record Template
### Incident Response Contact List
|Role|Primary Contact|Backup Contact|Phone|Email|Escalation Criteria|Notes|
|---|---|---|---|---|---|---|
||||||||

### Incident Severity Matrix
|Severity|Definition|Examples|Notification Timeframe|Required Approvals|Reporting Considerations|
|---|---|---|---|---|---|
|||||||

## 7. Evidence and Retention
- Approved IR plan
- Contact list
- Severity matrix
- Tabletop/exercise record
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
