# System and Communications Protection Policy

**Template ID:** SC-POL-001  
**Artifact Type:** Policy  
**Mapped CMMC Level 2 Controls:** 3.13.1, 3.13.2, 3.13.3, 3.13.4, 3.13.5, 3.13.6, 3.13.7, 3.13.8, 3.13.9, 3.13.10, 3.13.11, 3.13.12, 3.13.13, 3.13.14, 3.13.15, 3.13.16  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Establishes requirements for boundary protection, network segmentation, secure architecture, encryption, cryptographic key management, mobile code, VoIP, collaborative computing, and CUI protection in transit and at rest.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{IT_ADMIN_TITLE}} manages network, encryption, boundary, session, and communications controls.
- {{SYSTEM_OWNER_TITLE}} approves architecture, external connections, and risk-based exceptions.
- {{SECURITY_OFFICER_TITLE}} reviews firewall rules, cryptographic controls, and network evidence.
- Users may only transmit, store, or access CUI through approved channels and systems.

## 4. Requirements
- Communications at external and key internal boundaries must be monitored, controlled, and protected.
- Network communications must be denied by default and allowed by exception based on approved business need.
- CUI must be protected during transmission and at rest using approved safeguards, including FIPS-validated cryptography when cryptography is used to protect CUI confidentiality.
- Cryptographic keys must be established and managed securely throughout their lifecycle.
- Publicly accessible components must be logically or physically separated from internal networks.
- Mobile code, VoIP, collaborative computing, split tunneling, and session authenticity controls must be managed using approved procedures.

## 7. Evidence and Retention
- Firewall rule review
- Network diagrams
- Cryptographic inventory
- Key management records
- Mobile code/VoIP approvals
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
