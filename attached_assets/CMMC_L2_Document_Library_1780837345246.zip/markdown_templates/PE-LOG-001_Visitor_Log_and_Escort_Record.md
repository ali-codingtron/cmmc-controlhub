# Visitor Log and Escort Record

**Template ID:** PE-LOG-001  
**Artifact Type:** Log/Form  
**Mapped CMMC Level 2 Controls:** 3.10.3, 3.10.4  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Provides a standard visitor log and escort record for controlled areas.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{FACILITY_OWNER_TITLE}} manages physical access, visitor controls, and access devices.
- {{SYSTEM_OWNER_TITLE}} defines controlled areas where CUI systems or media are located.
- {{SECURITY_OFFICER_TITLE}} reviews physical access logs, device inventory, and exceptions.
- Employees and visitors must comply with escorting, badging, clean desk, and controlled area requirements.

## 6. Required Table / Record Template
### Visitor Log and Escort Record
|Date|Visitor Name|Company|Purpose|Controlled Area|Escort|Time In|Time Out|Badge/ID Issued|CUI Area Access?|Notes|
|---|---|---|---|---|---|---|---|---|---|---|
||||||||||||

## 7. Evidence and Retention
- Visitor logs
- Escort evidence
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
