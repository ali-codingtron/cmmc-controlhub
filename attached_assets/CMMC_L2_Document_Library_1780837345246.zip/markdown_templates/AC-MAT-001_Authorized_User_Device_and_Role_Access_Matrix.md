# Authorized User, Device, and Role Access Matrix

**Template ID:** AC-MAT-001  
**Artifact Type:** Matrix/Table  
**Mapped CMMC Level 2 Controls:** 3.1.1, 3.1.2, 3.1.4, 3.1.5, 3.1.7  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Provides a standard matrix for documenting authorized users, devices, processes, roles, privileges, and separation-of-duties constraints.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SYSTEM_OWNER_TITLE}} approves access based on business need and CUI handling requirements.
- {{IT_ADMIN_TITLE}} implements, changes, and disables logical access in approved systems.
- {{SECURITY_OFFICER_TITLE}} reviews privileged access, remote access, exceptions, and audit evidence.
- Users must protect authenticators, use only approved access methods, and immediately report suspected unauthorized access.

## 4. Requirements
- Each role must identify permitted transactions, functions, data repositories, administrative rights, and prohibited combinations of duties.
- The matrix must distinguish standard user, privileged administrator, service account, emergency account, external user, and device/system access.
- Entries must be reviewed for least privilege and separation of duties before approval and during periodic access reviews.

## 6. Required Table / Record Template
### Access Control Matrix
|Role/Account Type|Authorized Users or Groups|Authorized Devices/Systems|Permitted Transactions/Functions|CUI Repositories|Privileged Functions|Prohibited Duties/Conflicts|Approver|Review Date|Notes|
|---|---|---|---|---|---|---|---|---|---|
|||||||||||

## 7. Evidence and Retention
- Approved access control matrix
- Separation-of-duties review evidence
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
