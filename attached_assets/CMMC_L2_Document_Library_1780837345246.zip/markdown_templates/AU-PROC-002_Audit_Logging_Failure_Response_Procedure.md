# Audit Logging Failure Response Procedure

**Template ID:** AU-PROC-002  
**Artifact Type:** Procedure  
**Mapped CMMC Level 2 Controls:** 3.3.4  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines actions required when audit processing, log forwarding, log storage, or log integrity controls fail.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SECURITY_OFFICER_TITLE}} defines auditable events, log review cadence, and escalation criteria.
- {{IT_ADMIN_TITLE}} enables logging, preserves logs, and maintains time synchronization.
- {{SYSTEM_OWNER_TITLE}} supports investigations and approves retention exceptions.
- Privileged users must not disable logging without written authorization and compensating monitoring.

## 5. Procedure
1. Detect audit failures using platform alerts, storage thresholds, health checks, SIEM status, or manual review.
2. Classify the failure based on affected systems, duration, CUI impact, and whether audit records were lost or unavailable.
3. Notify {{SECURITY_OFFICER_TITLE}} and {{SYSTEM_OWNER_TITLE}} when logging is interrupted for CUI systems.
4. Restore logging, preserve available records, validate event generation, and document corrective action.
5. Open an incident if the failure indicates tampering, unauthorized modification, or materially affects investigation capability.

## 6. Required Table / Record Template
### Audit Failure Record
|Date/Time|System|Failure Type|Detected By|Impact|Notification Date|Corrective Action|Validated By|Closure Date|Incident ID/Notes|
|---|---|---|---|---|---|---|---|---|---|
|||||||||||

## 7. Evidence and Retention
- Audit failure alerts
- Corrective action tickets
- Validation evidence
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
