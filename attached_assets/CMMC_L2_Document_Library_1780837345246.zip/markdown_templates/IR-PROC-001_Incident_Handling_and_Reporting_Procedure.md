# Incident Handling and Reporting Procedure

**Template ID:** IR-PROC-001  
**Artifact Type:** Procedure  
**Mapped CMMC Level 2 Controls:** 3.6.1, 3.6.2  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines the operational process for triaging, escalating, containing, reporting, and closing incidents.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SECURITY_OFFICER_TITLE}} leads incident handling, evidence preservation, and reporting coordination.
- {{SYSTEM_OWNER_TITLE}} supports business impact decisions and remediation prioritization.
- {{IT_ADMIN_TITLE}} performs containment, eradication, recovery, and technical evidence collection.
- All personnel must promptly report suspected incidents, CUI exposure, account compromise, malware, or policy violations.

## 5. Procedure
1. Receive incident report through {{INCIDENT_REPORTING_CHANNEL}} and record initial details, reporter, systems, time observed, and suspected CUI impact.
2. Assign severity and response owner; preserve volatile and durable evidence as appropriate.
3. Contain the incident using approved actions such as account disablement, network isolation, malicious email removal, endpoint containment, or firewall block.
4. Analyze scope, root cause, affected accounts/devices/data, and whether CUI was exposed or potentially compromised.
5. Coordinate internal and external reporting as required by contract, law, regulation, cyber insurance, or customer notification obligations.
6. Recover systems, validate remediation, document lessons learned, and update controls, procedures, or training as needed.

## 6. Required Table / Record Template
### Incident Report and Action Register
|Incident ID|Date/Time Reported|Reporter|System/Data Affected|CUI Impact?|Severity|Containment Action|Reporting Required?|Owner|Status|Closure Date|Lessons Learned|
|---|---|---|---|---|---|---|---|---|---|---|---|
|||||||||||||

## 7. Evidence and Retention
- Incident reports
- Containment evidence
- External reporting evidence
- Closure records
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
