# External Systems, Portable Storage, and Public Content Procedure

**Template ID:** AC-PROC-004  
**Artifact Type:** Procedure  
**Mapped CMMC Level 2 Controls:** 3.1.20, 3.1.21, 3.1.22  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines controls for external system connections, portable storage use on external systems, and CUI protection on public-facing systems.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SYSTEM_OWNER_TITLE}} approves access based on business need and CUI handling requirements.
- {{IT_ADMIN_TITLE}} implements, changes, and disables logical access in approved systems.
- {{SECURITY_OFFICER_TITLE}} reviews privileged access, remote access, exceptions, and audit evidence.
- Users must protect authenticators, use only approved access methods, and immediately report suspected unauthorized access.

## 5. Procedure
1. Connections to external systems must be identified, verified, approved, and limited to authorized business purposes.
2. Terms and conditions for external system use must address CUI handling, access, storage, transmission, monitoring, and termination of access.
3. Organizational portable storage devices containing CUI must not be used on external systems unless specifically approved and protected.
4. Only authorized personnel may post public content on organizational websites, portals, social media, or public repositories.
5. Public content must be reviewed before posting and periodically thereafter to ensure CUI or nonpublic information is not disclosed.
6. Improper public posting must be removed immediately, documented, assessed as a potential incident, and remediated.

## 6. Required Table / Record Template
### External System and Public Content Review Log
|Date|System/Site|Owner|Content or Connection Reviewed|CUI Check Completed|Reviewer|Result|Removal/Remediation Needed|Ticket/Incident ID|Closure Date|
|---|---|---|---|---|---|---|---|---|---|
|||||||||||

## 7. Evidence and Retention
- External system list
- Connection agreements
- Public content review records
- Removal evidence
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
