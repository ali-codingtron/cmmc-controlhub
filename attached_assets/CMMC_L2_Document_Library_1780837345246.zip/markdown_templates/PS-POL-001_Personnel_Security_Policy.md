# Personnel Security Policy

**Template ID:** PS-POL-001  
**Artifact Type:** Policy  
**Mapped CMMC Level 2 Controls:** 3.9.1, 3.9.2  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Establishes personnel screening, access authorization, transfer, and termination requirements for personnel with access to CUI systems.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{HR_OWNER_TITLE}} performs screening, termination, and transfer notifications.
- {{SYSTEM_OWNER_TITLE}} approves system access after personnel screening and need-to-know validation.
- {{IT_ADMIN_TITLE}} executes access revocation, account disablement, and credential recovery.
- {{SECURITY_OFFICER_TITLE}} validates completion of personnel security evidence.

## 4. Requirements
- Individuals must be screened before being authorized access to CUI systems based on role, contract, legal, and organizational requirements.
- Access must be based on employment/contract status, need-to-know, role, and completion of prerequisite training or acknowledgements.
- Transfers, terminations, contract end, leave of absence, and role changes must trigger access review and timely modification or revocation.
- Credentials, authenticators, badges, keys, devices, media, and organization-owned property must be recovered or disabled during offboarding.
- Personnel security records must be retained and protected based on HR and security evidence requirements.

## 7. Evidence and Retention
- Screening records
- Access authorization records
- Termination/transfer checklist
- Credential revocation evidence
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
