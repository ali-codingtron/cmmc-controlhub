# Media Protection Policy

**Template ID:** MP-POL-001  
**Artifact Type:** Policy  
**Mapped CMMC Level 2 Controls:** 3.8.1, 3.8.2, 3.8.3, 3.8.4, 3.8.5, 3.8.6, 3.8.7, 3.8.8, 3.8.9  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Establishes requirements for protecting, marking, storing, transporting, sanitizing, destroying, and backing up media containing CUI.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SYSTEM_OWNER_TITLE}} approves the business use of media containing CUI.
- {{IT_ADMIN_TITLE}} enforces removable media, encryption, backup, and sanitization controls.
- {{SECURITY_OFFICER_TITLE}} reviews media handling records and CUI transport exceptions.
- Users must mark, protect, transport, store, and dispose of media containing CUI only as authorized.

## 4. Requirements
- Digital and paper media containing CUI must be physically controlled and securely stored when not in use.
- Access to CUI on media must be limited to authorized users with need-to-know.
- Media containing CUI must be marked and handled according to CUI handling requirements and distribution limits.
- Media must be sanitized or destroyed before disposal, reuse, release, or maintenance when CUI may be present.
- Transport of CUI media outside controlled areas must be authorized, protected, tracked, and encrypted when digital unless alternative physical safeguards are approved.
- Backup CUI must be protected at storage locations equivalent to production CUI safeguards.

## 7. Evidence and Retention
- Media inventory
- Transport records
- Sanitization records
- Backup protection records
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
