# Security Assessment Policy

**Template ID:** CA-POL-001  
**Artifact Type:** Policy  
**Mapped CMMC Level 2 Controls:** 3.12.1, 3.12.2, 3.12.3, 3.12.4  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Establishes requirements for control assessment, POA&M management, continuous monitoring, and system security plan maintenance.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SECURITY_OFFICER_TITLE}} owns control assessment, POA&M management, continuous monitoring, and SSP updates.
- {{SYSTEM_OWNER_TITLE}} approves the system boundary, control implementation status, and residual risk.
- {{IT_ADMIN_TITLE}} provides technical evidence and remediation updates.
- Control owners maintain evidence and notify the security owner of material changes.

## 4. Requirements
- Security controls must be assessed periodically to determine whether they are implemented and effective.
- Deficiencies must be documented in a POA&M or risk register with owner, corrective action, milestones, and target completion date.
- Controls must be monitored on an ongoing basis to maintain continued effectiveness.
- The system security plan must describe the system boundary, environment of operation, control implementation, and interconnections.
- SSP, POA&M, and control assessment evidence must be updated when significant changes occur.

## 7. Evidence and Retention
- Control assessment results
- POA&M tracker
- Continuous monitoring records
- SSP updates
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
