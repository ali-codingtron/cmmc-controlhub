# System Security Plan Template

**Template ID:** CA-PLAN-002  
**Artifact Type:** Plan  
**Mapped CMMC Level 2 Controls:** 3.12.4  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Provides a standard SSP outline for documenting the CUI system boundary, operating environment, control implementation, and interconnections.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SECURITY_OFFICER_TITLE}} owns control assessment, POA&M management, continuous monitoring, and SSP updates.
- {{SYSTEM_OWNER_TITLE}} approves the system boundary, control implementation status, and residual risk.
- {{IT_ADMIN_TITLE}} provides technical evidence and remediation updates.
- Control owners maintain evidence and notify the security owner of material changes.

## 4. Requirements
- The SSP must identify system name, owner, purpose, CUI types, boundary, components, users, locations, external connections, data flows, inherited controls, common controls, and control implementation statements.
- The SSP must be reviewed at {{SSP_REVIEW_FREQUENCY}} and updated when significant changes affect the system boundary, environment, controls, or interconnections.
- Control implementation narratives must be traceable to evidence and POA&M items where controls are not fully implemented.

## 6. Required Table / Record Template
### SSP Core Information Table
|Field|Response|
|---|---|
|||

### System Boundary Asset Inventory
|Asset/System|Type|Owner|Location|CUI Function|Managed By|Protection Role|Evidence Link|
|---|---|---|---|---|---|---|---|
|||||||||

## 7. Evidence and Retention
- System security plan
- System boundary inventory
- Data flow diagrams
- Interconnection records
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
