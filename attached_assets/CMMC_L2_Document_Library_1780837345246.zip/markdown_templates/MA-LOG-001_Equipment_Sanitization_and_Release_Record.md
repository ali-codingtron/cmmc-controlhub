# Equipment Sanitization and Release Record

**Template ID:** MA-LOG-001  
**Artifact Type:** Log/Form  
**Mapped CMMC Level 2 Controls:** 3.7.3  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Provides a record for documenting sanitization or protection actions before equipment leaves organizational control.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{IT_ADMIN_TITLE}} plans and performs maintenance using approved tools and methods.
- {{SYSTEM_OWNER_TITLE}} approves maintenance that affects CUI systems or service availability.
- {{SECURITY_OFFICER_TITLE}} reviews remote maintenance, sanitization, and access evidence.
- External maintenance personnel must be authorized, supervised, logged, and limited to approved activities.

## 6. Required Table / Record Template
### Equipment Sanitization and Release Record
|Asset ID|System/Device|CUI Present?|Sanitization Method|Performed By|Validated By|Release Destination|Release Date|Chain of Custody|Evidence Link|Notes|
|---|---|---|---|---|---|---|---|---|---|---|
||||||||||||

## 7. Evidence and Retention
- Sanitization record
- Chain of custody
- Release authorization
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
