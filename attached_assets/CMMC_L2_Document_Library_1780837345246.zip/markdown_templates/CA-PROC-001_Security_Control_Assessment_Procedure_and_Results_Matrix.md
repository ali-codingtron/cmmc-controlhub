# Security Control Assessment Procedure and Results Matrix

**Template ID:** CA-PROC-001  
**Artifact Type:** Procedure/Matrix  
**Mapped CMMC Level 2 Controls:** 3.12.1  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines how CMMC Level 2 controls are assessed, documented, scored internally, and tracked for remediation.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SECURITY_OFFICER_TITLE}} owns control assessment, POA&M management, continuous monitoring, and SSP updates.
- {{SYSTEM_OWNER_TITLE}} approves the system boundary, control implementation status, and residual risk.
- {{IT_ADMIN_TITLE}} provides technical evidence and remediation updates.
- Control owners maintain evidence and notify the security owner of material changes.

## 5. Procedure
1. Establish assessment scope, assessment period, control owners, evidence sources, assessment methods, and evidence retention location.
2. Assess each control using document review, interviews, testing, configuration evidence, logs, records, and observation as applicable.
3. Record implementation status, evidence, assessor notes, deficiencies, risk, and remediation actions.
4. Validate closure of deficiencies and update the SSP and POA&M as needed.
5. Retain assessment records for audit readiness and management review.

## 6. Required Table / Record Template
### Control Assessment Results Matrix
|Control ID|Control Owner|Assessment Method|Evidence Reviewed|Status|Finding/Gap|Risk|Remediation Needed|POA&M ID|Assessor/Reviewer|Review Date|Evidence Link|
|---|---|---|---|---|---|---|---|---|---|---|---|
|||||||||||||

## 7. Evidence and Retention
- Assessment plan
- Control test evidence
- Assessment results matrix
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
