# Physical Access Device Inventory and Review Log

**Template ID:** PE-REG-001  
**Artifact Type:** Register/Table  
**Mapped CMMC Level 2 Controls:** 3.10.5  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Provides a standard register for keys, badges, smart cards, access codes, locks, and other physical access devices.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{FACILITY_OWNER_TITLE}} manages physical access, visitor controls, and access devices.
- {{SYSTEM_OWNER_TITLE}} defines controlled areas where CUI systems or media are located.
- {{SECURITY_OFFICER_TITLE}} reviews physical access logs, device inventory, and exceptions.
- Employees and visitors must comply with escorting, badging, clean desk, and controlled area requirements.

## 4. Requirements
- Physical access devices must be issued only to authorized personnel and recovered or disabled when no longer required.
- Lost, stolen, duplicated, or compromised access devices must be reported and remediated immediately.
- Access device inventory must be reviewed at {{ACCESS_DEVICE_REVIEW_FREQUENCY}}.

## 6. Required Table / Record Template
### Physical Access Device Inventory
|Device ID|Type|Issued To|Area/System|Issue Date|Approver|Last Review|Return/Disable Date|Lost/Stolen?|Action Taken|Notes|
|---|---|---|---|---|---|---|---|---|---|---|
||||||||||||

## 7. Evidence and Retention
- Access device inventory
- Review log
- Lost/stolen device tickets
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
