# Risk Assessment Policy

**Template ID:** RA-POL-001  
**Artifact Type:** Policy  
**Mapped CMMC Level 2 Controls:** 3.11.1, 3.11.2, 3.11.3  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Establishes requirements for periodic risk assessments, vulnerability scanning, risk-based remediation, and risk register maintenance.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SECURITY_OFFICER_TITLE}} owns the risk assessment methodology, risk register, and vulnerability tracking.
- {{SYSTEM_OWNER_TITLE}} accepts or escalates residual risk and approves remediation priorities.
- {{IT_ADMIN_TITLE}} performs vulnerability scanning and technical remediation.
- Control owners provide evidence of risk treatment and remediation completion.

## 4. Requirements
- Risk to organizational operations, assets, individuals, and CUI must be assessed periodically and when material changes occur.
- Vulnerability scanning must be performed at {{VULNERABILITY_SCAN_FREQUENCY}} and when new vulnerabilities affecting CUI systems are identified.
- Vulnerabilities must be remediated according to risk, severity, exploitability, CUI exposure, and business impact.
- Risk decisions, remediation plans, exceptions, and residual risk acceptance must be documented and approved.
- The risk register and vulnerability tracker must be reviewed at {{RISK_REVIEW_FREQUENCY}}.

## 7. Evidence and Retention
- Risk assessments
- Risk register
- Vulnerability scan results
- Remediation tracker
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
