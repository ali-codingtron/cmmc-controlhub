# Incident Response Policy

**Template ID:** IR-POL-001  
**Artifact Type:** Policy  
**Mapped CMMC Level 2 Controls:** 3.6.1, 3.6.2, 3.6.3  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Establishes requirements for incident preparation, detection, analysis, containment, eradication, recovery, reporting, testing, and lessons learned.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SECURITY_OFFICER_TITLE}} leads incident handling, evidence preservation, and reporting coordination.
- {{SYSTEM_OWNER_TITLE}} supports business impact decisions and remediation prioritization.
- {{IT_ADMIN_TITLE}} performs containment, eradication, recovery, and technical evidence collection.
- All personnel must promptly report suspected incidents, CUI exposure, account compromise, malware, or policy violations.

## 4. Requirements
- Suspected or confirmed cybersecurity incidents involving CUI systems must be reported immediately through approved channels.
- Incidents must be handled using defined roles, severity levels, evidence preservation expectations, communications controls, and escalation paths.
- Incidents involving DoD CUI or contractually reportable events must be evaluated for external reporting obligations.
- Incident response capability must be tested at {{IR_TEST_FREQUENCY}} and updated based on lessons learned.
- Incident records must be retained and protected as sensitive security information.

## 7. Evidence and Retention
- Incident reports
- IR plan
- IR exercise reports
- Lessons learned records
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
