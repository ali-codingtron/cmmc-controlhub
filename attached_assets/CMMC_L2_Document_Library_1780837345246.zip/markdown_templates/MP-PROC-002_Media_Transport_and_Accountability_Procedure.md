# Media Transport and Accountability Procedure

**Template ID:** MP-PROC-002  
**Artifact Type:** Procedure  
**Mapped CMMC Level 2 Controls:** 3.8.5, 3.8.6  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines accountability and protection requirements for transporting media containing CUI outside controlled areas.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SYSTEM_OWNER_TITLE}} approves the business use of media containing CUI.
- {{IT_ADMIN_TITLE}} enforces removable media, encryption, backup, and sanitization controls.
- {{SECURITY_OFFICER_TITLE}} reviews media handling records and CUI transport exceptions.
- Users must mark, protect, transport, store, and dispose of media containing CUI only as authorized.

## 5. Procedure
1. Transport of CUI media outside controlled areas must be approved before movement unless covered by an approved recurring business process.
2. Digital media containing CUI must be encrypted during transport unless an approved alternative physical safeguard is documented.
3. Media transfers must be logged with sender, recipient, CUI category, protection method, transport method, dates, and receipt confirmation.
4. Lost, delayed, damaged, or unaccounted-for media must be reported as a potential incident immediately.

## 6. Required Table / Record Template
### Media Transfer and Transport Log
|Transfer ID|Media ID|CUI Category|Sender|Recipient|Transport Method|Encryption/Physical Safeguard|Date Sent|Date Received|Receipt Confirmed By|Incident/Ticket ID|Notes|
|---|---|---|---|---|---|---|---|---|---|---|---|
|||||||||||||

## 7. Evidence and Retention
- Transfer log
- Receipt confirmation
- Encryption evidence
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
