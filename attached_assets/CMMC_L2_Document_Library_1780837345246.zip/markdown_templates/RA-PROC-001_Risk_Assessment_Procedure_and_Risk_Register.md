# Risk Assessment Procedure and Risk Register

**Template ID:** RA-PROC-001  
**Artifact Type:** Procedure/Register  
**Mapped CMMC Level 2 Controls:** 3.11.1, 3.11.3  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines how risks are identified, analyzed, rated, treated, accepted, and tracked.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SECURITY_OFFICER_TITLE}} owns the risk assessment methodology, risk register, and vulnerability tracking.
- {{SYSTEM_OWNER_TITLE}} accepts or escalates residual risk and approves remediation priorities.
- {{IT_ADMIN_TITLE}} performs vulnerability scanning and technical remediation.
- Control owners provide evidence of risk treatment and remediation completion.

## 5. Procedure
1. Identify risks from system architecture, threat information, vulnerabilities, audit findings, incidents, changes, external dependencies, and CUI handling processes.
2. Evaluate likelihood, impact, CUI exposure, existing controls, residual risk, and affected business functions.
3. Assign risk owner, treatment strategy, due date, and approval authority based on severity.
4. Track remediation through closure or documented risk acceptance.
5. Review risk register at {{RISK_REVIEW_FREQUENCY}} and after significant system or threat changes.

## 6. Required Table / Record Template
### Risk Register
|Risk ID|Date Identified|Risk Statement|Affected System/Data|Likelihood|Impact|Inherent Risk|Existing Controls|Treatment Plan|Owner|Due Date|Residual Risk|Accepted By|Status|Evidence Link|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
||||||||||||||||

## 7. Evidence and Retention
- Risk register
- Risk acceptance approvals
- Treatment evidence
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
