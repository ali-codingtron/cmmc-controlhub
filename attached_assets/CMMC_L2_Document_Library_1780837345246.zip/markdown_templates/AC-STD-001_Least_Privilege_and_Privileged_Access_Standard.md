# Least Privilege and Privileged Access Standard

**Template ID:** AC-STD-001  
**Artifact Type:** Standard  
**Mapped CMMC Level 2 Controls:** 3.1.4, 3.1.5, 3.1.6, 3.1.7  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines minimum rules for least privilege, privileged account separation, privileged function execution, and logging of privileged activity.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SYSTEM_OWNER_TITLE}} approves access based on business need and CUI handling requirements.
- {{IT_ADMIN_TITLE}} implements, changes, and disables logical access in approved systems.
- {{SECURITY_OFFICER_TITLE}} reviews privileged access, remote access, exceptions, and audit evidence.
- Users must protect authenticators, use only approved access methods, and immediately report suspected unauthorized access.

## 4. Requirements
- Users must use non-privileged accounts for email, web browsing, productivity, collaboration, and other nonsecurity functions.
- Privileged functions must be limited to authorized roles and protected from execution by non-privileged users.
- Privileged actions must be logged and attributable to an individual user or approved service account.
- Shared privileged accounts are prohibited unless approved as a documented exception with compensating controls.
- Administrative privileges must be reviewed at {{PRIVILEGED_ACCESS_REVIEW_FREQUENCY}} and immediately upon role change or suspected compromise.

## 6. Required Table / Record Template
### Privileged Access Review
|Review Date|Account|Assigned User/Owner|Privileged Role|Business Need|Last Used|Reviewer|Keep/Modify/Revoke|Remediation Ticket|Completion Date|
|---|---|---|---|---|---|---|---|---|---|
|||||||||||

## 7. Evidence and Retention
- Privileged access approval
- Privileged access review
- Privileged command logs
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
