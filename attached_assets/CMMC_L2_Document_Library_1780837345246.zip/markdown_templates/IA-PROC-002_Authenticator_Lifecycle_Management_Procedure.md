# Authenticator Lifecycle Management Procedure

**Template ID:** IA-PROC-002  
**Artifact Type:** Procedure  
**Mapped CMMC Level 2 Controls:** 3.5.3, 3.5.4, 3.5.5, 3.5.6, 3.5.7, 3.5.8  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines issuing, resetting, revoking, replacing, protecting, and reviewing passwords, tokens, certificates, keys, and other authenticators.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{IT_ADMIN_TITLE}} issues, disables, and manages identifiers and authenticators.
- {{SECURITY_OFFICER_TITLE}} establishes authentication standards and reviews exceptions.
- {{SYSTEM_OWNER_TITLE}} approves access requiring elevated authentication or shared service usage.
- Users must protect passwords, tokens, certificates, recovery codes, and other authenticators.

## 5. Procedure
1. Issue authenticators only after identity validation and approved access request.
2. Deliver initial or reset authenticators using approved secure channels and require change upon first use when applicable.
3. Revoke or reset authenticators when compromise is suspected, personnel separate, access changes, or authenticators expire.
4. Store and transmit authenticators using approved protection mechanisms such as password vaults, certificate stores, hardware tokens, or encrypted channels.
5. Review authenticator inventory and high-risk authenticator events at {{AUTHENTICATOR_REVIEW_FREQUENCY}}.

## 6. Required Table / Record Template
### Authenticator Inventory and Reset Log
|Date|User/Service/Device|Authenticator Type|Action|Reason|Approved By|Performed By|Secure Delivery Method|Expiration/Review Date|Evidence Link|
|---|---|---|---|---|---|---|---|---|---|
|||||||||||

## 7. Evidence and Retention
- Authenticator inventory
- Reset records
- Compromise response records
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
