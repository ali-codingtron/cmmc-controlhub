# Boundary Protection, Network Segmentation, and Firewall Rule Review Standard

**Template ID:** SC-STD-001  
**Artifact Type:** Standard/Procedure  
**Mapped CMMC Level 2 Controls:** 3.13.1, 3.13.5, 3.13.6  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines boundary protection, DMZ/subnetwork separation, default-deny firewall posture, and firewall rule review requirements.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{IT_ADMIN_TITLE}} manages network, encryption, boundary, session, and communications controls.
- {{SYSTEM_OWNER_TITLE}} approves architecture, external connections, and risk-based exceptions.
- {{SECURITY_OFFICER_TITLE}} reviews firewall rules, cryptographic controls, and network evidence.
- Users may only transmit, store, or access CUI through approved channels and systems.

## 4. Requirements
- External boundaries and key internal boundaries must be documented in network diagrams and protected using managed devices or services.
- Publicly accessible system components must be placed in logically or physically separated subnetworks from internal networks.
- Firewall and security group rules must deny traffic by default and permit only approved traffic by exception.
- Rules must have owner, business justification, source, destination, service/port, approval, review date, and expiration where applicable.
- Firewall/network rules must be reviewed at {{FIREWALL_RULE_REVIEW_FREQUENCY}} and after significant network changes.

## 6. Required Table / Record Template
### Firewall Rule and Network Connection Register
|Rule ID|Boundary/Device|Source|Destination|Service/Port|Action|Business Justification|Owner|Approver|Review Date|Expiration|Status|Notes|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
||||||||||||||

## 7. Evidence and Retention
- Network diagrams
- Firewall rules
- Rule review evidence
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
