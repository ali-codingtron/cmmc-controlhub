# Media Sanitization and Disposal Procedure

**Template ID:** MP-PROC-003  
**Artifact Type:** Procedure  
**Mapped CMMC Level 2 Controls:** 3.8.3  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines sanitization, destruction, validation, and documentation requirements before media disposal or reuse.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SYSTEM_OWNER_TITLE}} approves the business use of media containing CUI.
- {{IT_ADMIN_TITLE}} enforces removable media, encryption, backup, and sanitization controls.
- {{SECURITY_OFFICER_TITLE}} reviews media handling records and CUI transport exceptions.
- Users must mark, protect, transport, store, and dispose of media containing CUI only as authorized.

## 5. Procedure
1. Determine whether media contains or may contain CUI before disposal, transfer, reuse, or release.
2. Select sanitization or destruction method appropriate to media type, CUI risk, system capability, and applicable standards.
3. Perform sanitization/destruction using approved personnel, tools, vendors, or services.
4. Validate completion where feasible and record certificate of destruction or equivalent evidence.
5. Update inventory and retain sanitization records.

## 6. Required Table / Record Template
### Media Sanitization and Destruction Record
|Media ID|Media Type|CUI Present?|Method|Tool/Vendor|Performed By|Validated By|Date|Certificate/ Evidence Link|Disposition|Notes|
|---|---|---|---|---|---|---|---|---|---|---|
||||||||||||

## 7. Evidence and Retention
- Sanitization records
- Certificates of destruction
- Inventory updates
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
