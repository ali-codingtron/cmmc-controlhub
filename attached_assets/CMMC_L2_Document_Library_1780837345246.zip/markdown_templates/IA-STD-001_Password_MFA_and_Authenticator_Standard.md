# Password, MFA, and Authenticator Standard

**Template ID:** IA-STD-001  
**Artifact Type:** Standard  
**Mapped CMMC Level 2 Controls:** 3.5.2, 3.5.3, 3.5.4, 3.5.5, 3.5.6, 3.5.7, 3.5.8, 3.5.9, 3.5.10, 3.5.11  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines baseline password, authenticator, MFA, temporary password, replay resistance, and obscured feedback requirements.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{IT_ADMIN_TITLE}} issues, disables, and manages identifiers and authenticators.
- {{SECURITY_OFFICER_TITLE}} establishes authentication standards and reviews exceptions.
- {{SYSTEM_OWNER_TITLE}} approves access requiring elevated authentication or shared service usage.
- Users must protect passwords, tokens, certificates, recovery codes, and other authenticators.

## 4. Requirements
- Passwords must meet {{PASSWORD_MIN_LENGTH}}, complexity or blocklist requirements, and reuse restrictions of {{PASSWORD_HISTORY_COUNT}} where technically supported.
- Temporary passwords must be unique, time-limited, securely delivered, and changed upon first use.
- Authenticators must be protected in storage and transmission and must not be shared.
- MFA must use approved factors such as {{APPROVED_MFA_METHODS}} and must be enforced for {{MFA_SCOPE}}.
- Authentication mechanisms must obscure feedback during authentication and use replay-resistant mechanisms where required or technically supported.
- Default authenticators must be changed before deployment or removed when not required.

## 6. Required Table / Record Template
### Authentication Standard Parameters
|Parameter|Approved Value|System/Scope|Technical Enforcement|Exception Allowed?|Evidence Location|
|---|---|---|---|---|---|
|||||||

## 7. Evidence and Retention
- Password/MFA settings
- Authenticator configuration
- Exception records
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
