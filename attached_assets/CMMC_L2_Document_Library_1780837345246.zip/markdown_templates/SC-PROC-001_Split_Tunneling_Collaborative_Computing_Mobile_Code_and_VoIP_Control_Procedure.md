# Split Tunneling, Collaborative Computing, Mobile Code, and VoIP Control Procedure

**Template ID:** SC-PROC-001  
**Artifact Type:** Procedure  
**Mapped CMMC Level 2 Controls:** 3.13.7, 3.13.12, 3.13.13, 3.13.14  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines controls for split tunneling, collaborative computing devices, mobile code, and VoIP technologies in CUI environments.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{IT_ADMIN_TITLE}} manages network, encryption, boundary, session, and communications controls.
- {{SYSTEM_OWNER_TITLE}} approves architecture, external connections, and risk-based exceptions.
- {{SECURITY_OFFICER_TITLE}} reviews firewall rules, cryptographic controls, and network evidence.
- Users may only transmit, store, or access CUI through approved channels and systems.

## 5. Procedure
1. Remote devices must not simultaneously connect to CUI systems and external networks through unapproved split tunneling paths unless risk-reviewed and technically controlled.
2. Collaborative computing devices must not be remotely activated without user indication and must provide visible/audible notice of activation when supported.
3. Mobile code technologies must be identified, approved, restricted, monitored, and disabled where not required.
4. VoIP technologies used in or connected to the CUI environment must be approved, monitored, and configured to prevent unauthorized use or disclosure.
5. Exceptions must be documented with risk analysis, compensating controls, owner, expiration, and approval.

## 6. Required Table / Record Template
### Mobile Code, VoIP, and Collaborative Technology Register
|Technology/System|Type|Business Purpose|CUI Impact|Approved Configuration|Owner|Monitoring Method|Approval Date|Review Date|Exception ID|Notes|
|---|---|---|---|---|---|---|---|---|---|---|
||||||||||||

## 7. Evidence and Retention
- Split tunnel configuration
- Technology approval register
- VoIP/collaboration settings evidence
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
