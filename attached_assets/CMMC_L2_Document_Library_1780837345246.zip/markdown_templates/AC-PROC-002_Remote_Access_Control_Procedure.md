# Remote Access Control Procedure

**Template ID:** AC-PROC-002  
**Artifact Type:** Procedure  
**Mapped CMMC Level 2 Controls:** 3.1.12, 3.1.13, 3.1.14, 3.1.15  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines authorization, monitoring, encryption, routing, and privileged command requirements for remote access into CUI systems.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SYSTEM_OWNER_TITLE}} approves access based on business need and CUI handling requirements.
- {{IT_ADMIN_TITLE}} implements, changes, and disables logical access in approved systems.
- {{SECURITY_OFFICER_TITLE}} reviews privileged access, remote access, exceptions, and audit evidence.
- Users must protect authenticators, use only approved access methods, and immediately report suspected unauthorized access.

## 5. Procedure
1. Remote access must be requested and approved before use, including user, device, access method, duration, and business justification.
2. Remote access must route through managed access control points such as approved VPN, ZTNA, bastion, remote desktop gateway, or secure administrative jump host.
3. Remote access sessions must use approved cryptographic mechanisms and MFA where required by policy and system capability.
4. Remote execution of privileged commands and access to security-relevant information must be separately authorized and logged.
5. Remote access sessions must be monitored and reviewed at {{REMOTE_ACCESS_REVIEW_FREQUENCY}} for unauthorized or anomalous activity.

## 6. Required Table / Record Template
### Remote Access Authorization Register
|User|Device|Remote Access Method|System/Resource|Privilege Level|Business Justification|Approval Date|Expiration Date|MFA Enabled|Managed Access Point|Reviewer|Status|
|---|---|---|---|---|---|---|---|---|---|---|---|
|||||||||||||

## 7. Evidence and Retention
- Remote access approvals
- VPN/gateway configuration evidence
- Remote access logs
- Privileged remote session records
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
