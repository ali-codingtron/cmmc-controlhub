# Change Management and Security Impact Analysis Procedure

**Template ID:** CM-PROC-001  
**Artifact Type:** Procedure  
**Mapped CMMC Level 2 Controls:** 3.4.3, 3.4.4  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines the workflow for reviewing, approving, testing, implementing, and documenting system changes.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SYSTEM_OWNER_TITLE}} approves baseline configurations and production changes.
- {{IT_ADMIN_TITLE}} maintains configuration baselines, software inventories, and secure settings.
- {{SECURITY_OFFICER_TITLE}} reviews security impact, change evidence, and configuration drift.
- Users may not install software or alter configurations unless explicitly authorized.

## 5. Procedure
1. Submit change request with description, business justification, affected assets, planned date, implementation steps, rollback plan, and CUI/security impact.
2. {{SECURITY_OFFICER_TITLE}} reviews changes for potential impact to access control, logging, encryption, network boundaries, CUI handling, monitoring, and documented control implementation.
3. {{SYSTEM_OWNER_TITLE}} approves or rejects the change based on risk, impact, timing, and business need.
4. {{IT_ADMIN_TITLE}} implements approved changes and records completion evidence.
5. Emergency changes must be documented and reviewed after implementation within {{EMERGENCY_CHANGE_REVIEW_DAYS}} business days.

## 6. Required Table / Record Template
### Change Request and Approval Log
|Change ID|Requestor|System|Description|Risk/Security Impact|Test Plan|Rollback Plan|Approver|Approval Date|Implemented By|Implementation Date|Validation|Status|Evidence Link|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|||||||||||||||

## 7. Evidence and Retention
- Change requests
- Security impact analysis
- Change approvals
- Validation evidence
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
