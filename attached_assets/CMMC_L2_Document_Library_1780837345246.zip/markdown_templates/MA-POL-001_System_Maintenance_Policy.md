# System Maintenance Policy

**Template ID:** MA-POL-001  
**Artifact Type:** Policy  
**Mapped CMMC Level 2 Controls:** 3.7.1, 3.7.2, 3.7.3, 3.7.4, 3.7.5, 3.7.6  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Establishes requirements for controlled maintenance of CUI systems, maintenance records, tool control, media sanitization, and remote maintenance.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{IT_ADMIN_TITLE}} plans and performs maintenance using approved tools and methods.
- {{SYSTEM_OWNER_TITLE}} approves maintenance that affects CUI systems or service availability.
- {{SECURITY_OFFICER_TITLE}} reviews remote maintenance, sanitization, and access evidence.
- External maintenance personnel must be authorized, supervised, logged, and limited to approved activities.

## 4. Requirements
- Maintenance must be authorized, scheduled, monitored, and documented for CUI systems.
- Maintenance tools must be approved, controlled, scanned, and removed or disabled when no longer needed.
- Equipment removed for off-site maintenance must be sanitized or protected based on CUI risk before release.
- Remote maintenance must be approved, encrypted, monitored, logged, and terminated when complete.
- Maintenance personnel must be authorized or escorted/supervised, and access must be limited to approved activities.

## 7. Evidence and Retention
- Maintenance records
- Tool inventory
- Remote maintenance logs
- Equipment sanitization records
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
