# Alternate Work Site Safeguarding Procedure

**Template ID:** PE-PROC-002  
**Artifact Type:** Procedure  
**Mapped CMMC Level 2 Controls:** 3.10.6  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines safeguarding requirements when CUI is accessed, processed, stored, or discussed from alternate work sites.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{FACILITY_OWNER_TITLE}} manages physical access, visitor controls, and access devices.
- {{SYSTEM_OWNER_TITLE}} defines controlled areas where CUI systems or media are located.
- {{SECURITY_OFFICER_TITLE}} reviews physical access logs, device inventory, and exceptions.
- Employees and visitors must comply with escorting, badging, clean desk, and controlled area requirements.

## 5. Procedure
1. Alternate work site access to CUI must be approved based on role, business need, device compliance, secure connectivity, and physical safeguarding capability.
2. Users must prevent unauthorized viewing, listening, recording, printing, storage, or access to CUI at alternate work sites.
3. CUI must be accessed using approved devices, approved networks, approved remote access methods, and approved storage locations.
4. Printing, removable media use, or local storage of CUI at alternate work sites is prohibited unless specifically approved and protected.
5. Lost or exposed CUI at alternate work sites must be reported as a potential incident.

## 6. Required Table / Record Template
### Alternate Work Site Authorization Record
|User|Location Type|Approved Device|Approved Access Method|CUI Activities Authorized|Restrictions|Approver|Approval Date|Review Date|Status|
|---|---|---|---|---|---|---|---|---|---|
|||||||||||

## 7. Evidence and Retention
- Alternate work approvals
- User acknowledgements
- Remote access evidence
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
