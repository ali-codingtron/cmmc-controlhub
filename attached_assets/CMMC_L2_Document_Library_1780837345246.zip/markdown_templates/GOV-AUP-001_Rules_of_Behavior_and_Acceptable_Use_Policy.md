# Rules of Behavior and Acceptable Use Policy

**Template ID:** GOV-AUP-001  
**Artifact Type:** Policy  
**Mapped CMMC Level 2 Controls:** 3.1.9, 3.2.1, 3.8.7, 3.8.8  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Provides user-facing rules of behavior for acceptable use of CUI systems, authenticators, media, remote access, and reporting obligations.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SYSTEM_OWNER_TITLE}} approves the business use of media containing CUI.
- {{IT_ADMIN_TITLE}} enforces removable media, encryption, backup, and sanitization controls.
- {{SECURITY_OFFICER_TITLE}} reviews media handling records and CUI transport exceptions.
- Users must mark, protect, transport, store, and dispose of media containing CUI only as authorized.

## 4. Requirements
- Users must access only systems, data, and functions for which they are authorized and have a business need.
- Users must not share passwords, tokens, recovery codes, badges, keys, or authenticators.
- Users must not store, transmit, print, post, copy, or remove CUI except through approved methods and approved systems.
- Users must not connect unauthorized devices, unknown portable storage, personal cloud services, or external systems to CUI systems without approval.
- Users must report suspected incidents, lost devices/media, unauthorized access, phishing, malware, or CUI exposure immediately.
- Users acknowledge that use may be monitored and that unauthorized activity may result in access removal and disciplinary or contractual action.

## 6. Required Table / Record Template
### User Acknowledgement Record
|User|Role|Policy Version|Acknowledgement Date|Training Complete?|Manager|Evidence Link|Notes|
|---|---|---|---|---|---|---|---|
|||||||||

## 7. Evidence and Retention
- User acknowledgements
- Rules of behavior
- Acceptable use records
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
