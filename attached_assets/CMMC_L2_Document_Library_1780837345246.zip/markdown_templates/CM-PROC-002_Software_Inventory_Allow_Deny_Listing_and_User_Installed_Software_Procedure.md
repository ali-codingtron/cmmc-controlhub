# Software Inventory, Allow/Deny Listing, and User-Installed Software Procedure

**Template ID:** CM-PROC-002  
**Artifact Type:** Procedure  
**Mapped CMMC Level 2 Controls:** 3.4.6, 3.4.7, 3.4.8, 3.4.9  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines how software is inventoried, approved, restricted, blocked, and monitored to prevent unauthorized software use.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SYSTEM_OWNER_TITLE}} approves baseline configurations and production changes.
- {{IT_ADMIN_TITLE}} maintains configuration baselines, software inventories, and secure settings.
- {{SECURITY_OFFICER_TITLE}} reviews security impact, change evidence, and configuration drift.
- Users may not install software or alter configurations unless explicitly authorized.

## 5. Procedure
1. Maintain an inventory of approved software, versions, publishers, business purpose, licensing owner, and approved installation scope.
2. Block or restrict unauthorized software using technical controls where supported, including application control, endpoint management, least privilege, or administrative approval.
3. Review software inventory at {{SOFTWARE_REVIEW_FREQUENCY}} for unauthorized, unsupported, or unnecessary software.
4. Only authorized personnel may install software on CUI systems unless user installation is explicitly approved, logged, and technically controlled.
5. Remove or remediate unauthorized software and document corrective action.

## 6. Required Table / Record Template
### Software Inventory and Allow/Deny List
|Software|Publisher|Version|Approved/Denied|Approved Systems/Users|Business Purpose|License Owner|Security Review Date|Status|Notes|
|---|---|---|---|---|---|---|---|---|---|
|||||||||||

## 7. Evidence and Retention
- Software inventory
- Allow/deny list
- Unauthorized software remediation evidence
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
