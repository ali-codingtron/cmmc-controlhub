# Wireless and Mobile Device Access Procedure

**Template ID:** AC-PROC-003  
**Artifact Type:** Procedure  
**Mapped CMMC Level 2 Controls:** 3.1.16, 3.1.17, 3.1.18, 3.1.19  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines authorization, authentication, encryption, management, and CUI protection requirements for wireless and mobile access.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SYSTEM_OWNER_TITLE}} approves access based on business need and CUI handling requirements.
- {{IT_ADMIN_TITLE}} implements, changes, and disables logical access in approved systems.
- {{SECURITY_OFFICER_TITLE}} reviews privileged access, remote access, exceptions, and audit evidence.
- Users must protect authenticators, use only approved access methods, and immediately report suspected unauthorized access.

## 5. Procedure
1. Wireless access must be explicitly authorized before connection to organizational systems or CUI environments.
2. Wireless access must use approved authentication and encryption mechanisms; open or unauthenticated wireless access to CUI systems is prohibited.
3. Mobile devices must be approved, inventoried, configured, encrypted, and managed before they may connect to CUI systems or store/transmit CUI.
4. CUI stored on mobile devices or mobile computing platforms must be encrypted using approved mechanisms or prohibited by configuration.
5. Lost, stolen, noncompliant, jailbroken/rooted, or unmanaged devices must be reported immediately and access must be revoked or quarantined.

## 6. Required Table / Record Template
### Wireless and Mobile Authorization Register
|Device/User|Device Type|Serial/Asset ID|Management Platform|Encryption Status|Wireless Network/Access Method|Approved CUI Use|Approver|Approval Date|Review Date|Status|Notes|
|---|---|---|---|---|---|---|---|---|---|---|---|
|||||||||||||

## 7. Evidence and Retention
- Wireless approvals
- Mobile device inventory
- Encryption evidence
- MDM compliance evidence
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
