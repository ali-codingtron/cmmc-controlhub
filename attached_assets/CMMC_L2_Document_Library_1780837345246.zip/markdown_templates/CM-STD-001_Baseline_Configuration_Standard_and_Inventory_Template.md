# Baseline Configuration Standard and Inventory Template

**Template ID:** CM-STD-001  
**Artifact Type:** Standard/Inventory  
**Mapped CMMC Level 2 Controls:** 3.4.1, 3.4.2  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines how baseline configurations are documented and maintained for CUI systems.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SYSTEM_OWNER_TITLE}} approves baseline configurations and production changes.
- {{IT_ADMIN_TITLE}} maintains configuration baselines, software inventories, and secure settings.
- {{SECURITY_OFFICER_TITLE}} reviews security impact, change evidence, and configuration drift.
- Users may not install software or alter configurations unless explicitly authorized.

## 4. Requirements
- Each in-scope system must have a documented baseline identifying operating system, applications, security tools, network settings, authentication settings, logging settings, encryption settings, and approved services.
- Baselines must be version-controlled and updated after approved changes.
- Baseline deviations must be documented as approved exceptions or remediated.

## 6. Required Table / Record Template
### Baseline Configuration Inventory
|Asset/System|Owner|Baseline Version|OS/Firmware|Approved Software|Security Tools|Encryption|Logging|Ports/Services|Last Reviewed|Approved By|Evidence Link|
|---|---|---|---|---|---|---|---|---|---|---|---|
|||||||||||||

## 7. Evidence and Retention
- Baseline inventory
- Configuration exports/screenshots
- Deviation records
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
