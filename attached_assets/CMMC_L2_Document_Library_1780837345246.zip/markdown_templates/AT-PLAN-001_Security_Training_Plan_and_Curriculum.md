# Security Training Plan and Curriculum

**Template ID:** AT-PLAN-001  
**Artifact Type:** Plan  
**Mapped CMMC Level 2 Controls:** 3.2.1, 3.2.2, 3.2.3  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines the annual and onboarding training curriculum for users, administrators, managers, and personnel with CUI responsibilities.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SECURITY_OFFICER_TITLE}} owns training content and completion monitoring.
- {{SYSTEM_OWNER_TITLE}} identifies role-based training needs for personnel with CUI responsibilities.
- Managers ensure personnel complete required training before access is granted and at required intervals.
- Users complete training and acknowledge applicable policies, standards, and procedures.

## 4. Requirements
- The curriculum must include CUI handling, phishing/social engineering, authentication, incident reporting, acceptable use, media handling, remote work, public posting restrictions, and insider threat awareness.
- Role-based modules must be assigned based on job duties and system privileges.
- Training materials must be reviewed at least annually and updated when policies, threats, technologies, or CUI handling requirements change.

## 6. Required Table / Record Template
### Training Curriculum Matrix
|Training Module|Audience|Frequency|Delivery Method|Completion Requirement|Owner|Mapped Controls|Evidence Location|
|---|---|---|---|---|---|---|---|
|||||||||

## 7. Evidence and Retention
- Approved curriculum
- Training material versions
- Training assignments
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
