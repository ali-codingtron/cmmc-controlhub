# Personnel Screening and Access Authorization Procedure

**Template ID:** PS-PROC-001  
**Artifact Type:** Procedure  
**Mapped CMMC Level 2 Controls:** 3.9.1  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines how personnel are screened before authorizing access to CUI systems.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{HR_OWNER_TITLE}} performs screening, termination, and transfer notifications.
- {{SYSTEM_OWNER_TITLE}} approves system access after personnel screening and need-to-know validation.
- {{IT_ADMIN_TITLE}} executes access revocation, account disablement, and credential recovery.
- {{SECURITY_OFFICER_TITLE}} validates completion of personnel security evidence.

## 5. Procedure
1. {{HR_OWNER_TITLE}} completes required pre-access screening steps based on role and contract requirements.
2. {{SYSTEM_OWNER_TITLE}} validates business need and CUI need-to-know before access approval.
3. Access must not be provisioned until screening, training, policy acknowledgements, and authorization are complete unless a documented exception is approved.
4. Screening records must be maintained by HR or designated records owner and referenced in access approval evidence.

## 6. Required Table / Record Template
### Personnel Screening and Access Authorization Record
|Person|Role|Employment/Contract Status|Screening Completed|Training Completed|Policy Acknowledgement|Access Approved By|Approval Date|Systems Authorized|Evidence Location|
|---|---|---|---|---|---|---|---|---|---|
|||||||||||

## 7. Evidence and Retention
- Screening evidence
- Access approval record
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
