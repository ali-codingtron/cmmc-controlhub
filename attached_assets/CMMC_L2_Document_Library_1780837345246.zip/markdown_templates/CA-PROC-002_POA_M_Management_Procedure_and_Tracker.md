# POA&M Management Procedure and Tracker

**Template ID:** CA-PROC-002  
**Artifact Type:** Procedure/Tracker  
**Mapped CMMC Level 2 Controls:** 3.12.2  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines how plans of action and milestones are created, approved, tracked, updated, and closed.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{SECURITY_OFFICER_TITLE}} owns control assessment, POA&M management, continuous monitoring, and SSP updates.
- {{SYSTEM_OWNER_TITLE}} approves the system boundary, control implementation status, and residual risk.
- {{IT_ADMIN_TITLE}} provides technical evidence and remediation updates.
- Control owners maintain evidence and notify the security owner of material changes.

## 5. Procedure
1. Create a POA&M item for each control deficiency, vulnerability, or risk-approved gap requiring corrective action.
2. Assign owner, milestones, target completion date, required resources, impacted controls, and validation method.
3. Review POA&M items at {{POAM_REVIEW_FREQUENCY}} and update status, milestones, blockers, and evidence.
4. Validate closure using objective evidence before marking an item complete.
5. Escalate overdue or high-risk POA&M items to {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 6. Required Table / Record Template
### POA&M Tracker
|POA&M ID|Control ID|Deficiency|Risk/Severity|Corrective Action|Owner|Milestone|Target Date|Status|Validation Method|Closure Evidence|Closed Date|Approver|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
||||||||||||||

## 7. Evidence and Retention
- POA&M tracker
- Milestone evidence
- Closure validation evidence
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
