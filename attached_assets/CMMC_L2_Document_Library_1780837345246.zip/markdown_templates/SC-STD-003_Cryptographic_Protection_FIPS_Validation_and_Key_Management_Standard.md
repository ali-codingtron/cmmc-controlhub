# Cryptographic Protection, FIPS Validation, and Key Management Standard

**Template ID:** SC-STD-003  
**Artifact Type:** Standard  
**Mapped CMMC Level 2 Controls:** 3.1.13, 3.1.19, 3.8.6, 3.13.8, 3.13.10, 3.13.11, 3.13.16  
**Organization:** {{ORGANIZATION_NAME}}  
**System/Scope:** {{SYSTEM_NAME}} / {{CMMC_SCOPE_NAME}}  
**Owner:** {{DOCUMENT_OWNER}}  
**Version:** {{VERSION}}  
**Effective Date:** {{EFFECTIVE_DATE}}  
**Next Review Date:** {{REVIEW_DATE}}  
**Classification:** {{CLASSIFICATION}}  

## 1. Purpose
Defines cryptographic protection requirements for CUI in transit, CUI at rest, remote access, mobile devices, media transport, and cryptographic key management.

## 2. Scope
This document applies to {{ORGANIZATION_NAME}} personnel, contractors, systems, components, applications, services, facilities, and third-party services that process, store, transmit, protect, administer, or have access to CUI within {{CMMC_SCOPE_NAME}}.

## 3. Roles and Responsibilities
- {{IT_ADMIN_TITLE}} manages network, encryption, boundary, session, and communications controls.
- {{SYSTEM_OWNER_TITLE}} approves architecture, external connections, and risk-based exceptions.
- {{SECURITY_OFFICER_TITLE}} reviews firewall rules, cryptographic controls, and network evidence.
- Users may only transmit, store, or access CUI through approved channels and systems.

## 4. Requirements
- CUI transmitted over external or untrusted networks must be protected using approved cryptographic mechanisms unless approved alternative physical safeguards apply.
- CUI at rest must be protected using approved encryption or other approved safeguards based on storage location and system capability.
- When cryptography is used to protect CUI confidentiality, FIPS-validated cryptographic modules must be used where required by contract or regulation.
- Cryptographic keys must have documented ownership, generation, storage, rotation, access control, backup, revocation, and destruction requirements.
- Cryptographic exceptions must be documented in the risk register, SSP, and POA&M where applicable.

## 6. Required Table / Record Template
### Cryptographic Inventory and Key Management Log
|System/Service|Use Case|Protocol/Algorithm|FIPS Validation Evidence|Key Owner|Key Location|Rotation Frequency|Last Rotated|Access Restricted To|Exception/Risk ID|Evidence Link|
|---|---|---|---|---|---|---|---|---|---|---|
||||||||||||

## 7. Evidence and Retention
- Crypto inventory
- FIPS validation evidence
- Key rotation records
- Encryption configuration evidence
- Retain records for {{EVIDENCE_RETENTION_PERIOD}} or longer if required by contract, legal hold, or incident response requirements.

## 9. Exceptions
Exceptions must be documented with business justification, risk analysis, compensating controls, expiration date, and approval from {{SYSTEM_OWNER_TITLE}} and {{SECURITY_OFFICER_TITLE}}.

## 10. Review and Approval
This document must be reviewed At least annually and when material changes occur.

| Name | Title | Approval | Date |
|---|---|---|---|
| {{APPROVER_NAME}} | {{APPROVER_TITLE}} | Approved | {{APPROVAL_DATE}} |
