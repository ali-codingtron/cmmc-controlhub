CMMC Level 2 Professional Document Template Library
Generated: 2026-06-07

Contents:
- CMMC_L2_Document_Library_Master.docx: Master Word document containing 67 professional templates.
- CMMC_L2_Control_Document_Map.xlsx: 110-row control-to-document map with template IDs, artifact types, records, and NIST 800-171A assessment object references.
- cmmc_l2_document_templates.json: Application-friendly JSON containing all template content, placeholders, mappings, sections, tables, and records.
- cmmc_l2_control_document_map.csv: CSV version of the control map.
- cmmc_l2_template_catalog.csv: CSV version of the template catalog.
- markdown_templates/: Individual Markdown versions of each document template for easy app import.

Important tailoring note:
These templates are professional starting points. Tailor each document to the organization's actual CUI scope, technologies, contracts, legal obligations, and operating model before approval and use.

Primary sources:
- NIST SP 800-171 Rev. 2: https://csrc.nist.gov/pubs/sp/800/171/r2/upd1/final
- NIST SP 800-171A: https://csrc.nist.gov/pubs/sp/800/171/a/final
- DoD CMMC Program Overview: https://dodcio.defense.gov/cmmc/About/
